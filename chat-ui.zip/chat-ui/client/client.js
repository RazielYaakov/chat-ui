
socket.on("connect", function() {
  console.log("connected to chat server!");
});
socket.on("disconnect", function() {
  console.log("disconnected from chat server!");
});

const myMsg = document.getElementById('myMsg');
const username = document.getElementById('username');
const allMsgsBox = document.getElementById('allMsgsBox');
const sendMsgButton = document.getElementById('sendMsgButton');

socket.on('spotim/chat',(msg)=>{
    console.log(msg);
    let div = document.createElement('div');
    let img = document.createElement('img');
    let usernameText = document.createElement('text');
    let msgText = document.createElement('text');

    div.className = "container-fluid";
    img.className = "avatar";
    usernameText.id = "usernameText";
    msgText.id = "msgText";

    if(msg.username == username.value && msg.avatar== "myAvatar")
    {
        usernameText.textContent = 'Me: ';
        msgText.style.color = "white";
        img.src = "img_avatar.png";
    }
    else{
        div.style.backgroundColor = "#9cad6d";
        usernameText.textContent = msg.username + ': ';
        msgText.style.color = "white";
        img.src = "otherAvatar.jpg";
    }
    
    msgText.textContent = msg.message;
        
    div.appendChild(img);
    div.appendChild(usernameText);
    div.appendChild(msgText);
    allMsgsBox.appendChild(div);
    div.scrollIntoView();
});

function sendMsg()
{
    if(myMsg.value != "")
    {
        socket.emit('spotim/chat',{avatar:"myAvatar",username:username.value,message:myMsg.value} , (data)=> {
          });
        myMsg.value='';
    }
    else{
        alert('you need to write some text before...');
    }
}

